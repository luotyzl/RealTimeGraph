﻿
namespace Rakon.Test.Core
{
    public interface IAsyncOperationContext
    {
        // For the purpose of this test the methods & properties have been removed.
        // Surprise us!
    }
}